<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
	</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<a class="navbar-brand" href="https://sourcecodester.com">Sourcecodester</a>
		</div>
	</nav>
	<div class="col-md-2"></div>
	<div class="col-md-8 well">
		<h3 class="text-primary">PHP - Simple Copy File By Dragging</h3>
		<hr style="border-top:1px dotted #ccc;"/>
		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#form_modal"><span class="glyphicon glyphicon-plus"></span> Add file</button>
		<br /><br />
		<div class="col-md-5">
			<h4>File 1</h3>
			<div class="table-responsive">
				<table class="table table-bordered">
					<thead class="alert-info">
						<tr>
							<th>Filename</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$files = scandir('file1/');
							$count=0;
							foreach ($files as $file){
								if($file != '.' && $file !='..'){
						?>
						<tr>
							<td>
								<?php
									if(file_exists("file2/".$file)){	
								?>
									<label><?php echo $file?></label>
								<?php
									}else{
								?>
									<label draggable="true" id="<?php echo $file?>" ondragstart="drag(event);"><?php echo $file?></label>
								<?php
									}
								?>
							</td>
							<td>
								<?php
									if(file_exists("file2/".$file)){	
								?>
									<center>Copied</center>
								<?php
									}
								?>
							</td>
						</tr>
						<?php
								}
							}
						?>
					
					</tbody>
				</table>
			</div>
		</div>
		<div class="col-md-2" style="border:5px solid #ccc; padding:10px;">
			<img src="images/copy.png" width="100%" ondrop="drop(event)" ondragover="dragOver(event)"/>
		</div>
		<div class="col-md-5">
			<h4>File 2</h3>
			<div class="table-responsive">
				<table class="table table-bordered">
					<thead class="alert-info">
						<tr>
							<th>Filename</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$files = scandir('file2/');
							foreach ($files as $file){
								if($file != '.' && $file !='..'){
						?>
						<tr>
							<td><?php echo $file?></td>
						</tr>
						<?php
								}
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="modal fade" id="form_modal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<form action="save_file.php" method="POST" enctype="multipart/form-data">
				<div class="modal-content">
					<div class="modal-body">
						<div class="col-md-3"></div>
						<div class="col-md-6">
							<form method="POST" action="">
								<div class="form-group">
									<label>File:</label>
									<input type="file" name="file" class="form-control" required="required"/>
								</div>
							</form>
						</div>
					</div>
					<div style="clear:both;"></div>
					<div class="modal-footer">
						<button type="button" class="btn btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Close</button>
						<button name="save" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</body>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>
</html>