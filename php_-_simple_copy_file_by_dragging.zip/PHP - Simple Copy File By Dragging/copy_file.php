<?php
	if(ISSET($_REQUEST['file'])){
		$file = "file1/".$_REQUEST['file'];
		$newfile = "file2/".$_REQUEST['file'];
		
		if(!copy($file, $newfile)){
			echo "<script>alert('Failed to copy ".$file."')</script>";
			echo "<script>window.location = 'index.php'</script>";
		}else{
			echo "<script>alert('Copied!')</script>";
			echo "<script>window.location = 'index.php'</script>";
		}
	}
?>